Go to https://medium.com/@filipefborba/tutorial-using-deep-learning-and-cnns-to-make-a-hand-gesture-recognition-model-371770b63a51

By the time this file was uploaded, the article had 88 views and 6 claps in less than 2 days!
